// JavaScript for ORDER NOW buttons
document.querySelectorAll('.btn').forEach(button => {
    button.addEventListener('click', () => {
      // Replace with your desired action, e.g., alert or redirect
      alert('Order placed!');
    });
  });
  